[ Tic Tac Toe ]

Tic Tac Toe is a classic 3x3 board game where the goal is to be the first player to form a horizontal, vertical, or diagonal line with your marks (O or X). You can either play against another person in two-player mode or challenge the AI in single-player mode.

The AI offers two difficulty levels(easy and hard)so you can challenge yourself.

Enjoy the game!


[ Prerequisites ]

Before running the program, ensure that you have the following installed:

- Python 3.x (recommended)

To verify your Python installation, run the following command:

=================
python3 --version
=================


[ Installation & Usage ]

1. Extract the Tic_Tac_Toe.zip file.
2. Navigate to the extracted Tic_Tac_Toe directory.
   - You can do this by right-clicking the folder and selecting 'Open in Terminal'.
   - Or you can use the command line:
     =======================
     cd Tic_Tac_Toe
     =======================
   - To confirm you are in the correct directory, run:
     ====
     ls
     ====
     You should see 'main.py' listed in the output.
3. Run the program using the following command:
   ===============
   python3 main.py
   ===============
4. Adjust the terminal window size to ensure proper display of ASCII art.


[ Contact ]

For inquiries, feedback, or further details, feel free to reach out:

- Email: seojy2263@gmail.com
- Blog: https://jooyeunseo.github.io/