import os
import time
import random
import copy

LOGO = r'''
___         ___         ___
 |  o  _     |  _  _     |  _  _
 |  | (_     | (_|(_     | (_)(/_

'''

################### Setting class ################### 
class Setting:
    def __init__(self):
        self.gamemode, self.player1, self.player2 = self.mode()
        self.first_turn, self.first_mark = self.turn()
        self.level = self.level()

    # select the game mode
    def mode(self):
        while True:
            mode = input("Select the mode (1p / 2p): ").strip().upper()
            if mode.upper() == "1P":
                return "ai", "human", "computer"
            elif mode.upper() == "2P":
                return "pvp", "player1", "player2"
            else:
                print("Invalid input. Please select '1p' or '2p'.\n")

    # select the first player
    def turn(self):
        while True:
            turn = input(f"Who starts first? ('1' for {self.player1} / '2' for {self.player2}): ")
            if turn == "1":
                return self.player1, "O"     # human or player1 will start first
            elif turn == "2":
                return self.player2, "X"     # computer or player2 will start first
            else:
                print("Invalid input. Please select '1' or '2'.\n")

    # choose the level of computer AI(when the game mode is '1p')
    def level(self):
        if self.player2 == "computer":
            while True:
                level = input("Choose the level. ('0' for easy / '1' for hard): ")
                if level == "0":
                    return 0
                elif level == "1":
                    return 1
                else:
                    print("Invalid input. Please select '0' or '1'.\n")
        else:
            return None

################### Board class ################### 
class Board:
    def __init__(self):
        self.board = [
            [" ", " ", " "],
            [" ", " ", " "],
            [" ", " ", " "]
        ]
        self.marked_cells = 0

    # print the current board
    def print_board(self):
        print(LOGO)
        print("         1   2   3")  # number for row
        print("       +---+---+---+")
        for i, row in enumerate(self.board):
            print(f"     {i + 1} | " + " | ".join(row) + " |")  # number for column and row(array)
            print("       +---+---+---+")

    # human choose the cell
    def select_cell(self, player):
        while True:
            choice = input(f"{player}'s turn!\nEnter the row and column number of the spot: ").strip()
            if choice == "00":
                return None, None
            elif choice.isdigit() and len(choice) == 2 and 1 <= int(choice[0]) <= 3 and 1 <= int(choice[1]) <= 3:
                if self.board[int(choice[0]) - 1][int(choice[1]) - 1] == " ":
                    return int(choice[0]) - 1, int(choice[1]) - 1
                else:
                    print("That spot is already taken. Try again!\n")
            else:
                print("Invalid input. Please enter a two-digit number between 11 and 33.\n")

    # mark on the selected cell
    def mark_cell(self, row, col, mark):
        if mark == "O":
            self.board[row][col] = "O"
        else:
            self.board[row][col] = "X"
        self.marked_cells += 1

    # get only empty cells on the board
    def get_empty_cells(self):
        empty_cells = []
        for row in range(3):
            for col in range(3):
                if self.board[row][col] == " ":
                    empty_cells.append( (row, col) )
        return empty_cells

    # check if someone wins
    def final_state(self):
        # player1 wins
        if any([
            self.board[0][0] == self.board[0][1] == self.board[0][2] == "O",
            self.board[1][0] == self.board[1][1] == self.board[1][2] == "O",
            self.board[2][0] == self.board[2][1] == self.board[2][2] == "O",
            self.board[0][0] == self.board[1][0] == self.board[2][0] == "O",
            self.board[0][1] == self.board[1][1] == self.board[2][1] == "O",
            self.board[0][2] == self.board[1][2] == self.board[2][2] == "O",
            self.board[0][0] == self.board[1][1] == self.board[2][2] == "O",
            self.board[0][2] == self.board[1][1] == self.board[2][0] == "O"
        ]):
            return 1
        # player2 wins
        if any([
            self.board[0][0] == self.board[0][1] == self.board[0][2] == "X",
            self.board[1][0] == self.board[1][1] == self.board[1][2] == "X",
            self.board[2][0] == self.board[2][1] == self.board[2][2] == "X",
            self.board[0][0] == self.board[1][0] == self.board[2][0] == "X",
            self.board[0][1] == self.board[1][1] == self.board[2][1] == "X",
            self.board[0][2] == self.board[1][2] == self.board[2][2] == "X",
            self.board[0][0] == self.board[1][1] == self.board[2][2] == "X",
            self.board[0][2] == self.board[1][1] == self.board[2][0] == "X"
        ]):
            return 2
        # no one wins yet(doesn't mean it is draw)
        return 0

    # check if board is full
    def is_full(self):
        return self.marked_cells == 9

################### AI class ################### 
class AI:
    def __init__(self, level):
        self.level = level

    # computer will randomly choose the cell
    def easy_level(self, board):
        empty_cells = board.get_empty_cells()
        rnd_idx = random.randrange(0, len(empty_cells))
        return empty_cells[rnd_idx]

    # computer will choose the cell with minimax algorithm logic
    def hard_level(self, board, maximizing): 
        # score of winning case
        case = board.final_state()  
        if case == 1:                   # player1 wins(human)
            return -1, None
        elif case == 2:                 # player2 wins(computer)
            return 1, None

        # score of draw case
        if board.is_full():             
            return 0, None

        # score when it's computer's turn
        if maximizing:              
            max_eval = -100     # initialize the max value(so you can renew it with +1)
            best_move = None
            empty_cells = board.get_empty_cells()

            for (row, col) in empty_cells:
                temp_board = copy.deepcopy(board)   # deep copy of real board
                temp_board.mark_cell(row, col, "X") # mark at the copied board
                eval = self.hard_level(temp_board, maximizing=False)[0] # next turn(recursion)
                if eval > max_eval:
                    max_eval = eval
                    best_move = (row, col)
            return max_eval, best_move

        # score when it's human's turn
        elif not maximizing:
            min_eval = 100      # initialize the min value(so you cna renew it with -1)
            best_move = None
            empty_cells = board.get_empty_cells()

            for (row, col) in empty_cells:
                temp_board = copy.deepcopy(board)
                temp_board.mark_cell(row, col, "O")
                eval = self.hard_level(temp_board, maximizing=True)[0]  # next turn(recursion)
                if eval < min_eval:
                    min_eval = eval
                    best_move = (row, col)
            return min_eval, best_move

    # return computer's choice
    def eval(self, board, player):
        if self.level == 0:                 # easy level
            eval = "random"
            move = self.easy_level(board)
        if self.level == 1:                 # hard level
            if player == "human":
                eval, move = self.hard_level(board, maximizing=False)
            if player == "computer":
                eval, move = self.hard_level(board, maximizing=True)

        print(f"Computer placed the mark at ({move[0]+1}, {move[1]+1}) with an evaluation score of: {eval}")
        time.sleep(1)
        return move

################### Game class ################### 
class Game:
    def __init__(self, first_turn, first_mark):
        self.board = Board()
        self.player = first_turn
        self.mark = first_mark
        self.is_running = True

    # clear the screen
    def clear_screen(self):
        if os.name == 'nt':         # Windows
            os.system('cls')
        elif os.name == 'posix':    # macOS or Linux
            os.system('clear')
        else:
            pass                    # pass in different environments

    # pass the turn to the next player
    def next_turn(self, player1, player2):
        if self.player == player1:
            self.player = player2
            self.mark = "X"
        else:
            self.player = player1
            self.mark = "O"

    # check if game is over
    def is_over(self, player):
        if self.board.final_state() == 0 and not self.board.is_full():
            return False
        else:
            self.clear_screen()
            self.board.print_board()
            if self.board.final_state() == 2 and player == "computer":
                print(f"\n😭 {player} wins!")
            elif self.board.final_state() != 0:
                print(f"\n🥳 {player} wins!")
            elif self.board.is_full():
                print("\n😐 It is draw...")
            return True

################### Main ################### 
def main():
    print(LOGO)
    print("Let's play Tic Tac Toe!\n")

    setting = Setting()
    game = Game(setting.first_turn,setting.first_mark)
    ai = AI(setting.level)
    board = game.board

    while game.is_running:
        game.clear_screen()
        board.print_board()
        print(f"[ {setting.player1}: O | {setting.player2}: X ]\n")

        if not board.is_full():                         # if there are still empty cell(s)
            if game.player == "computer":                   # and it's computer's turn
                row, col = ai.eval(board, game.player)          # automatically choose the cell
            else:                                           # and it's human's turn
                row, col = board.select_cell(game.player)       # will choose the cell they want

                if row is None:                             # if player chooses to exit the game
                    print("\n😵 Exit the game.")
                    game.is_running = False
                    break

            board.mark_cell(row, col, game.mark)            # mark at the selected cell

        if game.is_over(game.player):                   # Check if the game is over
            game.is_running= False                              # end the game
        else:
            game.next_turn(setting.player1, setting.player2)    # pass the turn

################### Game play ################### 
main()