[ Morse Code Converter ]

Morse Code Converter is a Python-based tool that encodes text into Morse code. It supports alphabets and numbers, making it a simple solution for encoding messages.


[ Prerequisites ]

Before running the program, ensure that you have the following installed:

- Python 3.x (recommended)

To verify your Python installation, run the following command:

=================
python3 --version
=================


[ Installation & Usage ]

1. Extract the Morse_Code_Converter.zip file.
2. Navigate to the extracted Morse_Code_Converter directory.
   - You can do this by right-clicking the folder and selecting 'Open in Terminal'.
   - Or you can use the command line:
     =======================
     cd Morse_Code_Converter
     =======================
   - To confirm you are in the correct directory, run:
     ====
     ls
     ====
     You should see main.py listed in the output.
3. Run the program using the following command:
   ===============
   python3 main.py
   ===============
4. Adjust the terminal window size to ensure proper display of ASCII art.


[ Contact ]

For inquiries, feedback, or further details, feel free to reach out:

- Email: seojy2263@gmail.com
- Blog: https://jooyeunseo.github.io/