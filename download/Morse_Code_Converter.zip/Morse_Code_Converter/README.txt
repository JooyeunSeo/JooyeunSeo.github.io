[Morse Code Converter]

This is a simple Python program that converts input text into Morse code. It supports alphabets and numbers. Hope you can use it well for encoding messages!


[Prerequisites]

Before running the program, make sure you have the following installed:

- Python 3.x (Python 3 is recommended)

You can check your Python version by running:
#################
python3 --version
#################


[Installation]

1. Extract the Morse_Code_Converter.zip archive.
2. Navigate to the Morse_Code_Converter directory(right-click on the folder and open the terminal).
3. Run the program by executing:
   ###############
   python3 main.py
   ###############
4. Please resize the window to display the ASCII art correctly.


[Contact]

For any questions or for more details, feel free to reach out to:

- Email: seojy2263@gmail.com
- Blog: https://jooyeunseo.github.io/