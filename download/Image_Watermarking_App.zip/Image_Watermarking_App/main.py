from PIL import Image, ImageTk, ImageDraw, ImageFont
import tkinter as tk
from tkinter import filedialog, colorchooser
import platform
import os
import sys


MAIN_COLOR = "#FFCACA"
SUB_COLOR = "#FFECEF"
TOP_WINDOW_COLOR = "#efedee"
WINDOW_WIDTH = 600
WINDOW_HEIGHT = 520
CANVAS_WIDTH = 250
CANVAS_HEIGHT = 300
TK_FONT = ("Arial", 12, "bold")
FONT_PATH = "Arial.ttf"

images = []                 # opened images
watermarked_img = None      # current watermarked image
is_first_img = True

watermark_pattern = "No Pattern"
watermark_text = "watermark"
font_size = 80
image_font = ImageFont.truetype(FONT_PATH, font_size)
watermark_rgb = (255, 255, 255)
watermark_hex = "#ffffff"
watermark_opacity = 80
watermark_rgba = (watermark_rgb[0], watermark_rgb[1], watermark_rgb[2], watermark_opacity)
watermark_position = "Top Left"
watermark_margin = 20

text_w = 0      # watermark text size
text_h = 0
thumb_w = 0     # thumnail image size
thumb_h = 0
watermark_ratio = (0, 0, 0, 0)

#------------------------------------------------------------------------------#
def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    base_path = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base_path, relative_path)

#------------------------------------------------------------------------------#
def set_image_font():
    ''' setup the font that supports Korean characters '''
    global FONT_PATH
    if platform.system() == 'Darwin':
        FONT_PATH = resource_path('AppleGothic.ttf')
    elif platform.system() == 'Windows' or platform.system() == 'Linux':
        FONT_PATH = resource_path('malgun.ttf')
    else:
        FONT_PATH = resource_path("Arial.ttf")

#------------------------------------------------------------------------------#
def image_uploads():
    ''' open images '''
    global images, thumb_w, thumb_h, watermark_ratio

    file_paths = filedialog.askopenfilenames(
        title = "Select Image(s)", filetypes=[("Image File", ["*.png", "*.jpg", "*.jpeg", "*.bmp"])]
    )
    if not file_paths:
        return
    
    # Initialize values for new images
    thumb_w = 0
    thumb_h = 0
    watermark_ratio = (0, 0, 0, 0)
    images.clear()

    for i, path in enumerate(file_paths):
        img = Image.open(path)
        img = correct_image_orientation(img)    # adjust orientation
        images.append( (path, img) )            # original image and path

    notice_label.config(text=f"Selected {len(images)} image(s). Only the first will be shown as a thumbnail.")
    save_setting_btn.config(state="normal", cursor="hand2")
    show_btn.config(state="normal", cursor="hand2")
    save_img_btn.config(state="normal", cursor="hand2")

    if images:
        save_setting()

#------------------------------------------------------------------------------#
def correct_image_orientation(img):
    ''' check EXIF orientation information and rotate image if necessary '''
    try:
        exif = img._getexif()       # get EXIF metadata of image

        if exif is not None:
            for tag, value in exif.items():
                if tag == 274:      # EXIF orientation tag number
                    if value == 3:      # image is 180° rotated
                        img = img.rotate(180, expand=True)
                    elif value == 6:    # image is rotated 90° clockwise
                        img = img.rotate(270, expand=True)
                    elif value == 8:    # image is rotated 90° counterclockwise
                        img = img.rotate(90, expand=True)
    except (AttributeError, KeyError, IndexError):  
        pass                            # no EXIF info, no 274 tag, no data

    return img

#------------------------------------------------------------------------------#
def change_text_content():
    ''' update watermark content '''
    global watermark_text
    watermark_text = text_entry.get()

def change_font_size(value):
    ''' update watermark size '''
    global font_size, image_font
    font_size = int(value)
    image_font = ImageFont.truetype(FONT_PATH, font_size)

def change_text_opacity(value):
    ''' update watermark opacity '''
    global watermark_opacity, watermark_rgba
    watermark_opacity = int(value)
    watermark_rgba = (watermark_rgb[0], watermark_rgb[1], watermark_rgb[2], watermark_opacity)

def change_text_color():
    ''' update watermark color '''
    global watermark_rgb, watermark_hex, watermark_rgba
    color = colorchooser.askcolor()
    if color[0]:    # when user actually select any color
        watermark_rgb = color[0]
        watermark_hex = color[1]
        watermark_rgba = (watermark_rgb[0], watermark_rgb[1], watermark_rgb[2], watermark_opacity)
        select_color_label.config(text=f"🎨 {watermark_hex} ", fg=watermark_hex)

def change_watermark_position(position, window):
    ''' update watermark position on the image '''
    global watermark_position
    watermark_position = position    
    select_pos_label.config(text=f"📍 {watermark_position} ")
    window.destroy()

def change_watermark_pattern(pattern, window):
    ''' update watermark pattern on the image '''
    global watermark_pattern
    watermark_pattern = pattern
    select_pattern_label.config(text=f"📏 {watermark_pattern} ")
    window.destroy()

#------------------------------------------------------------------------------#
def pos_setting_window():
    ''' open a new window to select the watermark position '''
    pos_window = tk.Toplevel()
    pos_window.title("Select Watermark Position")
    pos_window.geometry("320x120+300+150")
    pos_window.config(padx=10, pady=10, bg=TOP_WINDOW_COLOR)

    positions = [(0,0,"Top Left"), (0,2,"Top Right"), (1,1,"Center"), (2,0,"Bottom Left"), (2,2,"Bottom Right")]
    for row, col, position in positions:
        button = tk.Button(pos_window, text=position, highlightbackground=TOP_WINDOW_COLOR,
                           command=lambda p=position: change_watermark_position(p, pos_window))
        button.grid(row=row, column=col, sticky="we")

    pos_window.transient(root)  # this window moves with main window
    pos_window.grab_set()       # can't click other tasks till you close the window

def pattern_setting_window():
    ''' open a new window to select the watermark position '''
    pattern_window = tk.Toplevel()
    pattern_window.title("Select Watermark Pattern")
    pattern_window.geometry("230x190+300+150")
    pattern_window.config(padx=20, pady=20, bg=TOP_WINDOW_COLOR)

    patterns = [(0," ","No Pattern"), (1,"／","Diagonal"), (2,"―","Horizontal"), (3," |","Vertical"), (4," •","Dotted")]
    for row, label, pattern in patterns:
        label = tk.Label(pattern_window, text=f"{label}  ", font=TK_FONT, bg=TOP_WINDOW_COLOR)
        label.grid(row=row, column=0, sticky="w", padx=20)
        button = tk.Button(pattern_window, text=pattern, highlightbackground=TOP_WINDOW_COLOR,
                           command=lambda p=pattern: change_watermark_pattern(p, pattern_window))
        button.grid(row=row, column=1, sticky="we")

    pattern_window.transient(root)
    pattern_window.grab_set()

#------------------------------------------------------------------------------#
def enter_color_label(event):
    ''' change background color when mouse hovers over the label '''
    select_color_label.config(bg=MAIN_COLOR)
def enter_pos_label(event):
    select_pos_label.config(bg=MAIN_COLOR)
def enter_pattern_label(event):
    select_pattern_label.config(bg=MAIN_COLOR)

def leave_color_label(event):
    ''' get original background color back when mouse leaves the label '''
    select_color_label.config(bg=SUB_COLOR)
def leave_pos_label(event):
    select_pos_label.config(bg=SUB_COLOR)
def leave_pattern_label(event):
    select_pattern_label.config(bg=SUB_COLOR)

#------------------------------------------------------------------------------#
def add_watermark_overlay(img, is_first_img):
    ''' watermark(text or pattern) image '''
    global watermarked_img, text_w, text_h, watermark_ratio, font_size, image_font

    img = img.convert("RGBA")       # convert the image's mode(add alpha channel)
    img_w, img_h = img.size
    overlay = Image.new("RGBA", img.size, (255, 255, 255, 0))   # fully transparent overlay
    draw = ImageDraw.Draw(overlay)

    # watermark(pattern) image
    if watermark_pattern == "Diagonal":
        for i in range(0, img_w + img_h, 50):
            draw.line([(0, img_h - i), (i, img_h)], fill=watermark_rgba, width=5)
    elif watermark_pattern == "Horizontal":
        for i in range(0, img_h, 50):
            draw.line([(0, i), (img_w, i)], fill=watermark_rgba, width=5)
    elif watermark_pattern == "Vertical":
        for i in range(0, img_w, 50):
            draw.line([(i, 0), (i, img_h)], fill=watermark_rgba, width=5)
    elif watermark_pattern == "Dotted":
        for i in range(0, img_w, 50):
            for j in range(0, img_h, 50):
                draw.ellipse([i, j, i+20, j+20], fill=watermark_rgba, width=2)
    
    # measure text size with first image, adjust text size with other images
    if is_first_img:
        x0, y0, x1, y1 = draw.textbbox((0, 0), watermark_text, font=image_font)
        text_w = x1 - x0
        text_h = y1 - y0
        watermark_ratio = (img_w, img_h, text_w, text_h)  # first image and watermark's information
    else:
        width_ratio = img_w / watermark_ratio[0]    # current image width / first image width
        height_ratio = img_h / watermark_ratio[1]   # current image height / first image height

        # use the smaller ratio to ensure the watermark fits within the image
        scale_ratio = min(width_ratio, height_ratio)

        # calculate new text size
        text_w = int(watermark_ratio[2] * scale_ratio)
        text_h = int(watermark_ratio[3] * scale_ratio)
        image_font = ImageFont.truetype(FONT_PATH, text_h)    # adjust font size based on scaled height

    # calculate x and y position of text
    if watermark_position == "Top Left":
        x_pos, y_pos = (watermark_margin + 10), watermark_margin
    elif watermark_position == "Top Right":
        x_pos, y_pos = (img_w - text_w - (watermark_margin + 10)), watermark_margin
    elif watermark_position == "Center":
        x_pos, y_pos = (img_w - text_w) // 2, ((img_h - text_h) // 2 - (text_h // 4))
    elif watermark_position == "Bottom Left":
        x_pos, y_pos = (watermark_margin + 10), (img_h - text_h - (watermark_margin + 20))
    elif watermark_position == "Bottom Right":
        x_pos, y_pos = (img_w - text_w - watermark_margin), (img_h - text_h - (watermark_margin + 20))

    # watermark(text) image
    draw.text((x_pos, y_pos), watermark_text, fill=watermark_rgba, font=image_font)
    watermarked_img = Image.alpha_composite(img, overlay)   # img + overlay

#------------------------------------------------------------------------------#
def update_thumbnail():
    ''' update new setting on thumbnail canvas'''
    global watermarked_img, thumb_w, thumb_h
    watermarked_img_copy = watermarked_img.copy()
    watermarked_img_copy.thumbnail( (CANVAS_WIDTH, CANVAS_HEIGHT) )# 최대크기 지정

    if thumb_w == 0 and thumb_h == 0:# 처음 저장 시에만 지정
        thumb_w, thumb_h = watermarked_img_copy.size

    thumbnail_tk = ImageTk.PhotoImage(watermarked_img_copy)
    bottom_r_canvas.delete("all")
    bottom_r_canvas.create_image((CANVAS_WIDTH - thumb_w) // 2, (CANVAS_HEIGHT - thumb_h) // 2, anchor="nw", image=thumbnail_tk)
    bottom_r_canvas.image = thumbnail_tk

#------------------------------------------------------------------------------#
def save_setting():
    ''' watermark (first)image with new setting and show it on thumbnail canvas '''
    add_watermark_overlay(images[0][1], is_first_img)
    update_thumbnail()

#------------------------------------------------------------------------------#
def show_origin_image():
    ''' Show original size of image with watermark and allow scrolling if image is too large '''
    show_img_window = tk.Toplevel()
    show_img_window.title("Check Original Size")
    show_img_window.maxsize(1200, 700)

    origin_tk = ImageTk.PhotoImage(watermarked_img)

    # frame for canvas and scrollbars
    origin_frame = tk.Frame(show_img_window)
    origin_frame.pack(fill="both", expand=True)

    # canvas for original size image
    origin_canvas = tk.Canvas(origin_frame, width=watermarked_img.width, height=watermarked_img.height)
    origin_canvas.grid(row=0, column=0, sticky="nsew")

    # scrollbars
    h_scrollbar = tk.Scrollbar(origin_frame, orient="horizontal", command=origin_canvas.xview)
    h_scrollbar.grid(row=1, column=0, sticky="ew")

    v_scrollbar = tk.Scrollbar(origin_frame, orient="vertical", command=origin_canvas.yview)
    v_scrollbar.grid(row=0, column=1, sticky="ns")

    # canvas + scrollbars
    origin_canvas.config(xscrollcommand=h_scrollbar.set, yscrollcommand=v_scrollbar.set)
    origin_canvas.create_image(0, 0, anchor="nw", image=origin_tk)

    # adjust size of layout
    origin_frame.grid_rowconfigure(0, weight=1)
    origin_frame.grid_columnconfigure(0, weight=1)
    # set the area for scrolling
    origin_canvas.config(scrollregion=origin_canvas.bbox("all"))

    show_img_window.transient(root)
    show_img_window.grab_set()

    show_img_window.mainloop()

#------------------------------------------------------------------------------#
def save_images():
    ''' watermark and save the images '''
    global watermarked_img, is_first_img
    
    save_folder = filedialog.askdirectory(title="Select Folder to Save Images")
    if not save_folder:
        return

    for idx, (path, img) in enumerate(images):
        filename, ext = os.path.splitext(os.path.basename(path))
        save_path = os.path.join(save_folder, f"{filename}_watermark{ext}") # filename_watermark.ext

        if idx != 0:
            is_first_img = False

        add_watermark_overlay(img, is_first_img)

        if img.mode != "RGBA":
            # some image formats needs to be RGB mode again(JPEG, BMP, BMP, etc.)
            watermarked_img = watermarked_img.convert("RGB")

        watermarked_img.save(save_path, quality=95)     # save image(quality parameter for JPEG)

    notice_label.config(text=f"Successfully saved {len(images)} image(s).")
    save_setting_btn.config(state="disabled")
    show_btn.config(state="disabled")
    save_img_btn.config(state="disabled")



#---------------------------------------------- setup  ----------------------------------------------#
root = tk.Tk()
root.title("Image Watermarking App")
root.geometry(f"{WINDOW_WIDTH}x{WINDOW_HEIGHT}+250+100")  # set the size and position of root
root.resizable(False, False)    # user can't change the size of window
root.config(padx=20, pady=10, bg=MAIN_COLOR)
set_image_font()

#---------------------------------------------- title logo ----------------------------------------------#
logo_img = tk.PhotoImage(file=resource_path("logo.png"))
title_canvas = tk.Canvas(width=WINDOW_WIDTH, height=80, bg=MAIN_COLOR, highlightthickness=0)
title_canvas.create_image(280, 40, image=logo_img)
title_canvas.pack(pady=5)

#---------------------------------------------- top frame ----------------------------------------------#
top_frame = tk.Frame(root, bg=MAIN_COLOR)
top_frame.pack(side="top")

## select images
select_img_btn = tk.Button(top_frame, text="📂 Select Images", highlightbackground=MAIN_COLOR, command=image_uploads)
select_img_btn.config(cursor="hand2")
select_img_btn.pack(side="left", padx=5)

## show original size of image with watermark
show_btn = tk.Button(top_frame, text="🖼️ Original Image", highlightbackground=MAIN_COLOR, command=show_origin_image)
show_btn.config(state="disabled")
show_btn.pack(side="left", padx=5)

## save watermarked images
save_img_btn = tk.Button(top_frame, text="💾 Save Images", anchor="center", highlightbackground=MAIN_COLOR, command=save_images)
save_img_btn.config(state="disabled")
save_img_btn.pack(side="left", padx=5)

#---------------------------------------------- give information ----------------------------------------------#
notice_label = tk.Label(root, text="Select the images first.", bg=MAIN_COLOR, fg="#000", font=("Arial", 13))
notice_label.pack(fill="x", pady=5)

#---------------------------------------------- bottom frame ----------------------------------------------#
bottom_frame = tk.Frame(root, bg=SUB_COLOR)
bottom_frame.pack(side="top", fill="both", expand=True, pady=10)

## bottom-left frame
bottom_l_frame = tk.Frame(bottom_frame, bg=SUB_COLOR)
bottom_l_frame.pack(side="left", fill="both", expand=True, padx=10, pady=10)

#### edit text content
text_entry_label = tk.Label(bottom_l_frame, text="Text:  ", background=SUB_COLOR, font=TK_FONT)
text_entry_label.grid(row=0, column=0, sticky="se", pady=5)
text_entry = tk.Entry(bottom_l_frame, width=20, highlightthickness=0)
text_entry.insert(0, watermark_text)
text_entry.grid(row=0, column=1, sticky="w")
text_entry_btn = tk.Button(bottom_l_frame, text="Apply", highlightbackground=SUB_COLOR, command=change_text_content)
text_entry_btn.grid(row=1, column=1, sticky="e")

#### edit text size
text_size_scale_label = tk.Label(bottom_l_frame, text="Size:  ", font=TK_FONT, bg=SUB_COLOR)
text_size_scale_label.grid(row=2, column=0, sticky="se")
text_size_scale = tk.Scale(bottom_l_frame, from_=10, to=255, orient="horizontal", length=184, relief="flat",
                           bg=SUB_COLOR, troughcolor="#fff",command=change_font_size)
text_size_scale.set(font_size)
text_size_scale.grid(row=2, column=1, sticky="nsw")

#### edit text opacity
text_opacity_scale_label = tk.Label(bottom_l_frame, text="Opacity:  ", font=TK_FONT, bg=SUB_COLOR)
text_opacity_scale_label.grid(row=3, column=0, sticky="se", pady=5)
text_opacity_scale = tk.Scale(bottom_l_frame, from_=10, to=255, orient="horizontal", length=184, relief="flat",
                              bg=SUB_COLOR, troughcolor="#fff", command=change_text_opacity)
text_opacity_scale.set(watermark_opacity)
text_opacity_scale.grid(row=3, column=1, sticky="nsw", pady=5)

#### edit text color
text_color_label = tk.Label(bottom_l_frame, text="Color:  ", font=TK_FONT, bg=SUB_COLOR)
text_color_label.grid(row=4, column=0, sticky="se", pady=10)
select_color_label = tk.Label(bottom_l_frame, text=f"🎨 {watermark_hex} ", font=TK_FONT, fg=watermark_hex, bg=SUB_COLOR)
select_color_label.grid(row=4, column=1, sticky="sw", pady=10)
select_color_label.bind("<Button-1>", lambda event: change_text_color())
select_color_label.bind("<Enter>", enter_color_label)
select_color_label.bind("<Leave>", leave_color_label)

#### edit text position
text_pos_label = tk.Label(bottom_l_frame, text="Position:  ", font=TK_FONT, bg=SUB_COLOR)
text_pos_label.grid(row=5, column=0, sticky="se", pady=5)
select_pos_label = tk.Label(bottom_l_frame, text=f"📍 {watermark_position} ", font=TK_FONT, bg=SUB_COLOR)
select_pos_label.grid(row=5, column=1, sticky="sw", pady=5)
select_pos_label.bind("<Button-1>", lambda event: pos_setting_window())
select_pos_label.bind("<Enter>", enter_pos_label)
select_pos_label.bind("<Leave>", leave_pos_label)

#### edit pattern
pattern_label = tk.Label(bottom_l_frame, text="Pattern:  ", font=TK_FONT, bg=SUB_COLOR)
pattern_label.grid(row=6, column=0, sticky="se", pady=10)
select_pattern_label = tk.Label(bottom_l_frame, text=f"📏 {watermark_pattern} ", font=TK_FONT, bg=SUB_COLOR)
select_pattern_label.grid(row=6, column=1, sticky="sw", pady=10)
select_pattern_label.bind("<Button-1>", lambda event: pattern_setting_window())
select_pattern_label.bind("<Enter>", enter_pattern_label)
select_pattern_label.bind("<Leave>", leave_pattern_label)

#### save setting
save_setting_btn = tk.Button(bottom_l_frame, text="🐾 Save Setting", highlightbackground=SUB_COLOR, command=save_setting)
save_setting_btn.config(state="disabled")
save_setting_btn.grid(row=7, column=1, sticky="sw")

## bottom-right canvas
bottom_r_canvas = tk.Canvas(bottom_frame, width=CANVAS_WIDTH, height=CANVAS_HEIGHT, bg="white", highlightthickness=0)
bottom_r_canvas.pack(side="left", padx=10, pady=10)

#-------------------------------------------------- run --------------------------------------------------#
root.mainloop()