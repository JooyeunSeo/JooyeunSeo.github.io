[ Image Watermarking App ]

This is a GUI-based application that allows you to easily add customizable watermarks to your images.
You can customize the watermark by adding text or patterns. For text watermarks, you can adjust the font size, transparency, color, and position to suit your needs.
The program also supports batch processing, enabling you to watermark multiple images with the same style in one go.
Additionally, the text size automatically scales to fit each image.


[ Prerequisites ]

Before running the program, ensure that you have the following installed:

- Python 3.x (recommended)

   To verify your Python installation, run the following command:
   =================
   python3 --version
   =================

- libraries in the requirements.txt file (for Windows users)

   Navigate to the program directory and run the following command in the terminal:
   ===============================
   pip install -r requirements.txt    
   ===============================


[ Installation & Usage ]

1. Extract the 'Image_Watermarking_App.zip' file.

2. For macOS users: Open the 'dist' folder and run the 'Image Watermarking App' file with the paw icon.

3. For Windows users: Navigate to the extracted 'Image_Watermarking_App' directory.
   - You can do this by right-clicking the folder and selecting 'Open in Terminal'.
   - Or you can use the command line:
     =========================
     cd Image_Watermarking_App
     =========================
   - To confirm you are in the correct directory, run:
     ====
     ls
     ====
     You should see 'main.py' listed in the output.

4. Run the program using the following command:
   ===============
   python3 main.py
   ===============


[ Contact ]

For inquiries, feedback, or further details, feel free to reach out:

- Email: seojy2263@gmail.com
- Blog: https://jooyeunseo.github.io/