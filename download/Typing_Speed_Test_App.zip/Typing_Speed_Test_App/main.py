import tkinter as tk
import pygame
import random
import os
import sys

WINDOW_WIDTH = 800
WINDOW_HEIGHT = 500
BG_COLOR = "#577BC1"
POINT_COLOR = "#000957"
CURRENT_WORD_COLOR = "#FFEB00"
NEXT_WORD_COLOR = "#bcbcbc"
WARNING_COLOR = "#ff0000"
VALUE_COLOR = "#ffffff"
FONT_NAME = "Arial"
TIME_LIMIT = 60
INITIAL_BG_VOLUME = 0.6

#------------------------------------------------------------------------------#
class App(tk.Tk):
    def __init__(self):
        # parent class
        super().__init__()

        # main setup
        self.title("Typing Speed Test App")
        self.geometry(f"{WINDOW_WIDTH}x{WINDOW_HEIGHT}+280+130")
        self.resizable(False, False)
        self.config(padx=20, pady=20, bg=BG_COLOR)
        
        # values
        self.file_access = False
        self.words = []
        self.current_word = "Press Start"
        self.next_word = ""
        self.wpm = 0
        self.accuracy = 0
        self.total_words = 0
        self.wrong_words = 0
        self.correct_words = 0

        # widgets
        self.top = Top(self)
        self.records = Records(self)
        self.highestWPM = HighestWPM(self)
        self.typing = Typing(self)
        self.setting = Setting(self)

        # initialize pygame audio
        pygame.mixer.init()
        ## background music
        pygame.mixer.music.load(self.resource_path("assets/sound-background.mp3"))
        pygame.mixer.music.play(-1)
        pygame.mixer.music.set_volume(INITIAL_BG_VOLUME)
        ## sounds
        self.ticking_sound = pygame.mixer.Sound(self.resource_path("assets/sound-ticking.mp3"))
        self.timeup_sound = pygame.mixer.Sound(self.resource_path("assets/sound-timeup.mp3"))
        self.correct_sound = pygame.mixer.Sound(self.resource_path("assets/sound-correct.mp3"))
        self.wrong_sound = pygame.mixer.Sound(self.resource_path("assets/sound-wrong.mp3"))
        self.key_sound = pygame.mixer.Sound(self.resource_path("assets/sound-keyboard.mp3"))
        self.highscore_sound = pygame.mixer.Sound(self.resource_path("assets/sound-highscore.mp3"))

        # run
        self.mainloop()


    def resource_path(self, relative_path):
        """Get absolute path to resource, works for dev and for PyInstaller"""
        base_path = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
        return os.path.join(base_path, relative_path)
    
    def guide_window(self):
        """new window from the guide button"""
        new_window = tk.Toplevel(self)
        new_window.title("Game Guide")
        new_window.geometry("460x300+380+230")
        new_window.resizable(False, False)
        new_window.config(padx=10, pady=10, bg=POINT_COLOR)
        new_window.transient(self)
        new_window.grab_set()

        # widgets
        about_wpm_label_1 = tk.Label(new_window, text="What is WPM?", font=(FONT_NAME, 23, "bold italic"), fg=CURRENT_WORD_COLOR, bg=POINT_COLOR)
        about_wpm_label_2 = tk.Label(new_window, justify="left", font=(FONT_NAME, 15), fg=VALUE_COLOR, bg=POINT_COLOR,
                                     text="WPM (Words Per Minute) measures\nhow many words you type per minute.")
        howtoplay_label_1 = tk.Label(new_window, text="How to Play", font=(FONT_NAME, 23, "bold italic"), fg=CURRENT_WORD_COLOR, bg=POINT_COLOR)
        howtoplay_label_2 = tk.Label(new_window, justify="left", font=(FONT_NAME, 12), fg=VALUE_COLOR, bg=POINT_COLOR,
                                     text="⌨️ Press the Start button and type the displayed word.\n"
                                          "⌨️ Hit the Space key or Enter key to proceed.\n"
                                          "⌨️ The next word is displayed below the current one.\n"
                                          "⌨️ You can add your own words by editing the text file.\n"
                                          "⌨️ Type as many words as possible within 1 minute!")

        about_wpm_label_1.pack(padx=10, pady=10)
        about_wpm_label_2.pack()
        howtoplay_label_1.pack(padx=10, pady=10)
        howtoplay_label_2.pack()

#------------------------------------------------------------------------------#
class Top(tk.Frame):
    def __init__(self, parent):
        # make frame inside parent widget(root window)
        super().__init__(parent)
        self.place(x=0, y=0, relwidth=1, relheight=0.2)
        self.config(bg=BG_COLOR)

        self.top_label = tk.Label(text="Typing Speed Challenge", fg=POINT_COLOR, font=(FONT_NAME, 45, "bold italic"), bg=BG_COLOR)        
        self.top_label.pack(fill="both")

#------------------------------------------------------------------------------#
class Records(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        # save App instance
        self.parent = parent  
        self.timer_remaining = TIME_LIMIT
        # grid
        self.grid_columnconfigure(0, weight=0)  # 1st column
        self.grid_columnconfigure(1, weight=1)  # 2nd column

        self.create_timer()
        self.create_records()
        
        self.place(x=0, rely=0.2, relwidth=0.3, relheight=0.8)
        self.config(bg=BG_COLOR)


    def create_timer(self):
        """create timer image and text"""
        # create canvas for timer
        canvas_width = 200
        canvas_height = 200
        self.timer_canvas = tk.Canvas(self, width=canvas_width, height=canvas_height, bg=BG_COLOR, highlightthickness=0)
        self.timer_canvas.grid(row=0, column=0, columnspan=2, sticky="n", pady=20)
        ## timer image
        self.timer_img = tk.PhotoImage(file=self.parent.resource_path("assets/timer.png"))
        self.timer_canvas.create_image(canvas_width // 2, canvas_height // 2, image=self.timer_img)
        ## timer text
        self.timer_text = self.timer_canvas.create_text(canvas_width // 2, (canvas_height // 2)+10, text="1:00",
                                                        fill=VALUE_COLOR, font=(FONT_NAME, 35, "bold"))

    def create_records(self):
        """create record labels"""
        wpm_label = tk.Label(self, text="WPM : ", fg=POINT_COLOR, font=(FONT_NAME, 13, "bold"), bg=BG_COLOR)
        accuracy_label = tk.Label(self, text="Accuracy : ", fg=POINT_COLOR, font=(FONT_NAME, 13, "bold"), bg=BG_COLOR)
        total_words_label = tk.Label(self, text="Total Words : ", fg=POINT_COLOR, font=(FONT_NAME, 13, "bold"), bg=BG_COLOR)
        wrong_words_label = tk.Label(self, text="Wrong Words : ", fg=POINT_COLOR, font=(FONT_NAME, 13, "bold"), bg=BG_COLOR)
        
        self.wpm_value = tk.Label(self, text="?", fg=VALUE_COLOR, font=(FONT_NAME, 13, "bold"), bg=BG_COLOR)
        self.accuracy_value = tk.Label(self, text="0%", fg=VALUE_COLOR, font=(FONT_NAME, 13, "bold"), bg=BG_COLOR)
        self.total_words_value = tk.Label(self, text=self.parent.total_words, fg=VALUE_COLOR, font=(FONT_NAME, 13, "bold"), bg=BG_COLOR)
        self.wrong_words_value = tk.Label(self, text=self.parent.wrong_words, fg=VALUE_COLOR, font=(FONT_NAME, 13, "bold"), bg=BG_COLOR)

        wpm_label.grid(row=1, column=0, sticky="se")
        accuracy_label.grid(row=2, column=0, sticky="se")
        total_words_label.grid(row=3, column=0, sticky="se")
        wrong_words_label.grid(row=4, column=0, sticky="se")
        self.wpm_value.grid(row=1, column=1, padx=10)
        self.accuracy_value.grid(row=2, column=1, padx=10)
        self.total_words_value.grid(row=3, column=1, padx=10)
        self.wrong_words_value.grid(row=4, column=1, padx=10)

    def start_timer(self):
        """start timer"""
        self.timer_job = self.after(1000, self.update_timer)

    def update_timer(self):
        """countdown the timer from 60 seconds"""        
        if self.timer_remaining >= 0:
            minutes = self.timer_remaining // 60
            seconds = self.timer_remaining % 60
            self.timer_canvas.itemconfig(self.timer_text, text=f"{minutes:01}:{seconds:02}")
            
            # start to play ticking sound since 5s left
            if self.timer_remaining == 5:
                self.parent.ticking_sound.play()
                self.timer_canvas.itemconfig(self.timer_text, fill=WARNING_COLOR)

            self.timer_remaining -= 1                             # decrease 1s
            self.timer_job = self.after(1000, self.update_timer)  # update timer after 1s(save ID)
        else:
            pygame.mixer.stop()                                         # stop ticking sound
            self.parent.timeup_sound.play()                             # play timeup sound
            self.after(2000, lambda: self.parent.timeup_sound.stop())   # stop timeup sound after 2s
            self.timer_canvas.itemconfig(self.timer_text, fill=VALUE_COLOR)
            self.parent.typing.game_end()

    def stop_timer(self):
        """force to stop the timer(with stop button)"""
        if hasattr(self, "timer_job"):
            self.after_cancel(self.timer_job)  # stop timer with saved ID
        pygame.mixer.stop()                    # stop all the sound
        self.parent.typing.game_end()
        
    def calculate_wpm(self):
        """calculate wpm(after timer is over or stopped by user)"""
        elapsed_time = TIME_LIMIT - self.timer_remaining
        
        if elapsed_time < 1:                # when the first word is correct while elapsed time is 0
            elapsed_time = 1
    
        if self.parent.correct_words == 0:  # no correct word yet
            pass
        else:
            self.parent.wpm = int(self.parent.correct_words / (elapsed_time / TIME_LIMIT))
        self.wpm_value.config(text=self.parent.wpm)

    def calculate_accuracy(self):
        """calculate accuracy(everytime enter the new word)"""
        if self.parent.correct_words != 0:
            self.parent.accuracy = (self.parent.correct_words / self.parent.total_words) * 100
            self.accuracy_value.config(text=f"{self.parent.accuracy:.2f}%")

    def reset_values(self):
        """reset the recorded values for the new game"""
        self.timer_remaining = TIME_LIMIT
        self.parent.wpm = 0
        self.parent.accuracy = 0
        self.parent.total_words = 0
        self.parent.wrong_words = 0
        self.parent.correct_words = 0
        self.parent.records.wpm_value.config(text="?")
        self.parent.records.accuracy_value.config(text="0%")
        self.parent.records.total_words_value.config(text=self.parent.total_words)
        self.parent.records.wrong_words_value.config(text=self.parent.wrong_words)
        self.parent.highestWPM.highest_WPM_label.config(text=f"Your highest WPM : {self.parent.highestWPM.highest_WPM}")

#------------------------------------------------------------------------------#
class HighestWPM(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self.parent = parent
        self.read_highestWPM()

        self.place(relx=0.3, rely=0.2, relwidth=0.7, relheight=0.1)
        self.config(bg=BG_COLOR)


    def read_highestWPM(self):
        """read highest WPM score from the file"""
        with open(self.parent.resource_path("highest WPM.txt"), "r") as data:
            self.highest_WPM = int(data.read())
        self.highest_WPM_label = tk.Label(self, pady=5, text=f"Your highest WPM : {self.highest_WPM}",
                                        fg=VALUE_COLOR, font=(FONT_NAME, 17, "bold"), bg=BG_COLOR)
        self.highest_WPM_label.pack(side="bottom", anchor="s")

    def update_highestWPM(self):
        "update the highest WPM score"
        if self.parent.wpm > self.highest_WPM:
            self.highest_WPM = self.parent.wpm
            self.highest_WPM_label.config(text=f"Your highest WPM : {self.highest_WPM} 🎉 𝒏𝒆𝒘!")
            with open(self.parent.resource_path("highest WPM.txt"), "w") as data:
                data.write(str(self.highest_WPM))

#------------------------------------------------------------------------------#
class Typing(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self.parent = parent
        self.create_test()
        self.load_words()

        self.place(relx=0.3, rely=0.3, relwidth=0.7, relheight=0.6)
        self.config(bg=POINT_COLOR)


    def play_key_sound(self, event):
        """input key pressing sound"""
        self.parent.key_sound.play()

    def create_test(self):
        """create words display and typing entry"""
        self.current_display = tk.Label(self, text=self.parent.current_word, fg=CURRENT_WORD_COLOR, font=(FONT_NAME, 40, "bold"), bg=POINT_COLOR)
        self.next_display = tk.Label(self, text="", fg=NEXT_WORD_COLOR, font=(FONT_NAME, 20), bg=POINT_COLOR)
        self.typing_entry = tk.Entry(self, width=19, relief="flat", insertwidth=4, insertbackground=CURRENT_WORD_COLOR,
                                     selectbackground=CURRENT_WORD_COLOR, fg=POINT_COLOR, font=(FONT_NAME, 30, "bold"))
        
        self.current_display.pack(expand=True)
        self.next_display.pack(expand=True)
        self.typing_entry.pack(expand=True)
        self.typing_entry.config(state=tk.DISABLED)
    
    def load_words(self):
        """bring the words from the txt file"""
        with open(self.parent.resource_path("sample words.txt"), "r") as samples:
            self.parent.words = samples.read().splitlines()

    def get_new_words(self):
        """get or renew the current word and the next word"""
        if self.parent.current_word == "Press Start":           # pick a word for start
            self.parent.current_word = random.choice(self.parent.words)
            self.parent.words.remove(self.parent.current_word)
        else:
            self.parent.current_word = self.parent.next_word    # next word will be the current word
        
        if not self.parent.words:                             # no more word left in the list
            self.load_words()                                 # bring the original list back

        self.parent.next_word = random.choice(self.parent.words)  # pick the next word
        self.parent.words.remove(self.parent.next_word)
        self.update_word_display()
    
    def update_word_display(self):
        """display current word and next word"""
        self.current_display.config(text=self.parent.current_word)
        self.next_display.config(text=self.parent.next_word)

    def start_typing(self):
        """game start(user type the word and press spacebar or enter key to move on the next word)"""
        self.parent.records.reset_values()                  # reset records if user starts the game again
        print(self.parent.file_access)
        if not self.parent.file_access:                     # check if user allowed file access(only first time)
            with open(self.parent.resource_path("highest WPM.txt"), "w") as data:
                data.write(str(self.parent.highestWPM.highest_WPM))
            self.parent.file_access = True

        self.get_new_words()
        self.parent.setting.start_btn.config(state="disabled")  # disable: start button
        self.parent.setting.stop_btn.config(state="normal")     # enable: stop button

        self.typing_entry.config(state=tk.NORMAL)               # enable: typing entry
        self.typing_entry.delete(0, tk.END)                     # empty the entry
        self.typing_entry.focus_set()                           # activate cursor
        # bind
        self.typing_entry.bind("<space>", self.check_input)
        self.typing_entry.bind("<Return>", self.check_input)
        self.typing_entry.bind("<KeyPress>", self.play_key_sound)
        # start timer
        self.parent.records.start_timer()

    def check_input(self, event):
        """check the word user input and update the records"""
        if self.parent.highestWPM.highest_WPM_label.cget("text").endswith("🎉 𝒏𝒆𝒘!"):
            self.parent.highestWPM.highest_WPM_label.config(text=f"Your highest WPM : {self.parent.highestWPM.highest_WPM}")

        user_input = self.typing_entry.get().strip()    # get input value
        if user_input:
            if user_input == self.parent.current_word:
                self.parent.correct_words += 1
            else:                                                                         
                self.parent.wrong_words += 1
                self.parent.records.wrong_words_value.config(text=self.parent.wrong_words)
                self.parent.wrong_sound.play()                  # wrong sound

            self.parent.total_words += 1
            self.parent.records.total_words_value.config(text=self.parent.total_words)
            self.parent.records.calculate_wpm()
            self.parent.records.calculate_accuracy()

            self.parent.highestWPM.update_highestWPM()
            if self.parent.highestWPM.highest_WPM_label.cget("text").endswith("🎉 𝒏𝒆𝒘!"): 
                self.parent.highscore_sound.play()              # correct & highscore sound
            else:                                                                         
                self.parent.correct_sound.play()                # correct sound

            self.typing_entry.delete(0, tk.END)     # empty the entry
            self.get_new_words()
        return "break"  # prevent the default behavior of spacebar and enter key

    def game_end(self):
        """finish the game and check the result"""
        self.typing_entry.config(state=tk.DISABLED)             # block the typing entry
        # unbind
        self.typing_entry.unbind("<space>")
        self.typing_entry.unbind("<Return>")
        self.typing_entry.unbind("<KeyPress>")

        self.parent.setting.stop_btn.config(state="disabled")   # block the stop button
        self.parent.setting.start_btn.config(state="normal")    # active the start button

#------------------------------------------------------------------------------#
class Setting(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self.parent = parent
        self.start()
        self.stop()
        self.guide()
        self.volume()

        self.place(relx=0.3, rely=0.9, relwidth=0.7, relheight=0.1)
        self.config(bg=BG_COLOR, padx=20, pady=5)


    def start(self):
        """start new game(button)"""
        self.start_btn = tk.Button(self, text="Start", command=self.parent.typing.start_typing, highlightbackground=BG_COLOR)
        self.start_btn.pack(side="left", anchor="sw", expand=True)

    def stop(self):
        """force to stop the game(button)"""
        self.stop_btn = tk.Button(self, text="Stop", highlightbackground=BG_COLOR, command=self.parent.records.stop_timer)
        self.stop_btn.pack(side="left", anchor="sw", expand=True)
        self.stop_btn.config(state="disabled")

    def guide(self):
        """explain about game(button)"""
        self.guide_btn = tk.Button(self, text="Game Guide", highlightbackground=BG_COLOR, command=self.parent.guide_window)
        self.guide_btn.pack(side="left", anchor="sw", expand=True)

    def volume(self):
        """volume button"""
        self.volume_scale = tk.Scale(self, from_=0, to=100, orient="horizontal", width=11, length=70, sliderlength=10,
                                     showvalue=True, font=(FONT_NAME, 10), fg=VALUE_COLOR,
                                     relief="flat", sliderrelief="flat", bg=BG_COLOR, troughcolor=VALUE_COLOR,
                                     command=self.adjust_volumes)
        self.volume_scale.set(50)
        self.volume_scale.pack(side="right")
        volume_label = tk.Label(self, text="🔉 ", bg=BG_COLOR, font=(FONT_NAME, 14))
        volume_label.pack(side="right", anchor="s")
    
    def adjust_volumes(self, scale):
        """calculate and adjust volume"""
        volume_value = float(scale) / 100       # convert (0-100) to (0.0-1.0)
        pygame.mixer.music.set_volume(INITIAL_BG_VOLUME * volume_value)
        self.parent.ticking_sound.set_volume(volume_value)
        self.parent.timeup_sound.set_volume(volume_value) 
        self.parent.correct_sound.set_volume(volume_value)
        self.parent.wrong_sound.set_volume(volume_value)
        self.parent.key_sound.set_volume(volume_value)
        self.parent.highscore_sound.set_volume(volume_value)

#--- create the root window ---#
App()