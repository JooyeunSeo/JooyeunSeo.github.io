[ Typing Speed Test App ]

This is a GUI-based typing game that provides a visually engaging experience, including a real-time countdown timer.
Test your WPM(words per minute) as you race against time.

Your highest WPM score is automatically saved, so you can track your progress even after restarting the game.
Additionally, you can customize the word list to create a unique challenge just for yourself.

Try to type as many words as possible within one minute and beat your own records. Are you ready for the challenge?


[ Prerequisites ]

Before running the program, ensure that you have the following installed:

- Python 3.x (recommended)

   To verify your Python installation, run the following command:
   =================
   python3 --version
   =================

- libraries in the requirements.txt file (for Windows users)

   Navigate to the program directory and run the following command in the terminal:
   ===============================
   pip install -r requirements.txt    
   ===============================


[ Installation & Usage ]

1. Extract the 'Typing_Speed_Test_App.zip' file.

2. For macOS users: Open the 'dist' folder and run the 'Typing Speed Test App' file with the keyboard icon.
   - To access the TXT file where the data is stored, right-click the app file and select 'Show Package Contents'.
     You can find it inside Contents > Frameworks.
   - "Typing Speed Test App" would like to access files in your Documents folder.
     If this message appears after pressing the Start button, please allow it.
3. For Windows users: Navigate to the extracted 'Typing_Speed_Test_App' directory.
   - You can do this by right-clicking the folder and selecting 'Open in Terminal'.
   - Or you can use the command line:
     =========================
     cd Typing_Speed_Test_App
     ========================= 
   - To confirm you are in the correct directory, run:
     ====
     ls
     ====
     You should see 'main.py' listed in the output.

4. Run the program using the following command:
   ===============
   python3 main.py
   ===============

5. Change the data by editing the TXT file.
   - Highest WPM score: 'highest WPM.txt'
   - word list: 'sample words.txt' (one word per line)


[ Contact ]

For inquiries, feedback, or further details, feel free to reach out:

- Email: seojy2263@gmail.com
- Blog: https://jooyeunseo.github.io/